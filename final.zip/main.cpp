// main.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include "Menu.hpp"

int main()
{
	//creates menu object because menu is a class
	Menu m;

	//directs to menu function
	m.menu();

	return 0;
}


